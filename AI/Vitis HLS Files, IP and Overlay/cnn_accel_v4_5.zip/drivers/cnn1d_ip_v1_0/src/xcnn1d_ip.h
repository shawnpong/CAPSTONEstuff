// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.1 (64-bit)
// Tool Version Limit: 2025.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XCNN1D_IP_H
#define XCNN1D_IP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xcnn1d_ip_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Ctrl_BaseAddress;
} XCnn1d_ip_Config;
#endif

typedef struct {
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XCnn1d_ip;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XCnn1d_ip_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XCnn1d_ip_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XCnn1d_ip_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XCnn1d_ip_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XCnn1d_ip_Initialize(XCnn1d_ip *InstancePtr, UINTPTR BaseAddress);
XCnn1d_ip_Config* XCnn1d_ip_LookupConfig(UINTPTR BaseAddress);
#else
int XCnn1d_ip_Initialize(XCnn1d_ip *InstancePtr, u16 DeviceId);
XCnn1d_ip_Config* XCnn1d_ip_LookupConfig(u16 DeviceId);
#endif
int XCnn1d_ip_CfgInitialize(XCnn1d_ip *InstancePtr, XCnn1d_ip_Config *ConfigPtr);
#else
int XCnn1d_ip_Initialize(XCnn1d_ip *InstancePtr, const char* InstanceName);
int XCnn1d_ip_Release(XCnn1d_ip *InstancePtr);
#endif

void XCnn1d_ip_Start(XCnn1d_ip *InstancePtr);
u32 XCnn1d_ip_IsDone(XCnn1d_ip *InstancePtr);
u32 XCnn1d_ip_IsIdle(XCnn1d_ip *InstancePtr);
u32 XCnn1d_ip_IsReady(XCnn1d_ip *InstancePtr);
void XCnn1d_ip_EnableAutoRestart(XCnn1d_ip *InstancePtr);
void XCnn1d_ip_DisableAutoRestart(XCnn1d_ip *InstancePtr);


void XCnn1d_ip_InterruptGlobalEnable(XCnn1d_ip *InstancePtr);
void XCnn1d_ip_InterruptGlobalDisable(XCnn1d_ip *InstancePtr);
void XCnn1d_ip_InterruptEnable(XCnn1d_ip *InstancePtr, u32 Mask);
void XCnn1d_ip_InterruptDisable(XCnn1d_ip *InstancePtr, u32 Mask);
void XCnn1d_ip_InterruptClear(XCnn1d_ip *InstancePtr, u32 Mask);
u32 XCnn1d_ip_InterruptGetEnabled(XCnn1d_ip *InstancePtr);
u32 XCnn1d_ip_InterruptGetStatus(XCnn1d_ip *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
